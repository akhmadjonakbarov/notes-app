import 'package:flutter/animation.dart';

class AppColors {
  static const Color backgroundColor = Color(0xFF252525);
  static const Color widgetsBackColor = Color(0xFF3B3B3B);
  static const Color formTextColor = Color(0xFF9A9A9A);
  static const Color green = Color(0xFF30BE71);
}
